﻿# FIWAKTI 56.33.11 - retour aux fichiers d'avant le correctif
# Usage : powershell -ExecutionPolicy Bypass -File .\RESTAURER-AVANT-CORRECTIF.ps1 -Sauvegarde "C:\FIWAKTI\correctifs\avant-correctif-AAAAMMJJ-HHMMSS"
param(
  [Parameter(Mandatory = $true)][string]$Sauvegarde,
  [string]$Racine  = "C:\FIWAKTI",
  [string]$Version = "56.33.11",
  [string]$Tache   = "FIWAKTI"
)
$ErrorActionPreference = "Stop"
$Dest = Join-Path $Racine ("versions\" + $Version)
if (-not (Test-Path $Sauvegarde)) { throw "Sauvegarde introuvable : $Sauvegarde" }
Stop-ScheduledTask -TaskName $Tache -ErrorAction SilentlyContinue
Start-Sleep -Seconds 5
Get-ChildItem -Path $Sauvegarde -Recurse -File | Where-Object { $_.Name -ne "VERSION.txt" } | ForEach-Object {
  $rel = $_.FullName.Substring($Sauvegarde.TrimEnd('\').Length + 1)
  $dst = Join-Path $Dest $rel
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
  Copy-Item $_.FullName $dst -Force
  Write-Host "restauré : $rel"
}
Start-ScheduledTask -TaskName $Tache
Write-Host "Fichiers d'avant le correctif restaurés. Rechargez les navigateurs (Ctrl+F5)." -ForegroundColor Green
