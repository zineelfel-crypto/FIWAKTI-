﻿# FIWAKTI 56.33.11 - installation du correctif 33 : Administration › Migration des données (cumulatif : correctifs 2 à 32)
# Usage (PowerShell en administrateur, dans ce dossier) :
#   powershell -ExecutionPolicy Bypass -File .\INSTALLER-CORRECTIF.ps1
# Options : -Racine C:\FIWAKTI  -Version 56.33.11  -Tache FIWAKTI  -Port 8080
# Le dossier des données (C:\FIWAKTI\donnees) n'est jamais lu ni modifié par ce script.
param(
  [string]$Racine  = "C:\FIWAKTI",
  [string]$Version = "56.33.11",
  [string]$Tache   = "FIWAKTI",
  [int]$Port       = 8080
)
$ErrorActionPreference = "Stop"
$Ici  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $Racine ("versions\" + $Version)

Write-Host "FIWAKTI $Version - correctif 33 (Migration des données, cumulatif)" -ForegroundColor Cyan
if (-not (Test-Path (Join-Path $Dest "serveur\principal.js"))) { throw "Installation introuvable : $Dest (vérifiez -Racine et -Version)." }

# 1. Contrôle des fichiers du correctif (empreintes SHA-256)
$Liste = @()
foreach ($l in Get-Content -Encoding UTF8 (Join-Path $Ici "EMPREINTES-SHA256.txt")) {
  if ($l -match '^([0-9a-f]{64})\s+(.+)$') { $Liste += ,@($Matches[1], $Matches[2].Trim()) }
}
if ($Liste.Count -eq 0) { throw "EMPREINTES-SHA256.txt vide ou illisible." }
foreach ($e in $Liste) {
  $src = Join-Path $Ici ("fichiers\" + $e[1].Replace('/', '\'))
  if (-not (Test-Path $src)) { throw "Fichier manquant dans le correctif : $($e[1])" }
  if ((Get-FileHash $src -Algorithm SHA256).Hash.ToLower() -ne $e[0]) { throw "Empreinte incorrecte (fichier altéré) : $($e[1])" }
}
Write-Host ("1/5 Correctif vérifié : " + $Liste.Count + " fichiers intègres.")

# 2. Arrêt du service
Stop-ScheduledTask -TaskName $Tache -ErrorAction SilentlyContinue
$libre = $false
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  $ecoute = $null
  try { $ecoute = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue } catch { }
  if (-not $ecoute) { $libre = $true; break }
}
if (-not $libre) { throw "Le port $Port est toujours occupé : arrêtez FIWAKTI (tâche planifiée « $Tache ») puis relancez ce script. Aucun fichier n'a été modifié." }
Write-Host "2/5 FIWAKTI arrêté."

# 3. Sauvegarde des fichiers remplacés
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Sauv  = Join-Path $Racine ("correctifs\avant-correctif-" + $Stamp)
New-Item -ItemType Directory -Force -Path $Sauv | Out-Null
foreach ($e in $Liste) {
  $rel = $e[1].Replace('/', '\'); $dst = Join-Path $Dest $rel
  if (Test-Path $dst) { $cible = Join-Path $Sauv $rel; New-Item -ItemType Directory -Force -Path (Split-Path -Parent $cible) | Out-Null; Copy-Item $dst $cible -Force }
}
Set-Content -Encoding UTF8 -Path (Join-Path $Sauv "VERSION.txt") -Value $Dest
Write-Host "3/5 Fichiers actuels sauvegardés dans $Sauv"

# 4. Copie et vérification
foreach ($e in $Liste) {
  $rel = $e[1].Replace('/', '\'); $src = Join-Path $Ici ("fichiers\" + $rel); $dst = Join-Path $Dest $rel
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
  Copy-Item $src $dst -Force
  if ((Get-FileHash $dst -Algorithm SHA256).Hash.ToLower() -ne $e[0]) { throw "Copie incorrecte : $($e[1]). Restaurez avec RESTAURER-AVANT-CORRECTIF.ps1 -Sauvegarde `"$Sauv`"" }
}
Write-Host "4/5 Fichiers installés et vérifiés."

# 5. Redémarrage
Start-ScheduledTask -TaskName $Tache
$ok = $false
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Seconds 2
  try { $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 ("http://localhost:" + $Port + "/connexion.html"); if ($r.StatusCode -eq 200) { $ok = $true; break } } catch { }
}
if ($ok) { Write-Host "5/5 FIWAKTI redémarré : http://localhost:$Port" -ForegroundColor Green }
else { Write-Host "5/5 FIWAKTI ne répond pas encore : consultez $Racine\donnees\journaux, ou restaurez avec RESTAURER-AVANT-CORRECTIF.ps1 -Sauvegarde `"$Sauv`"" -ForegroundColor Yellow }
Write-Host ""
Write-Host "Dans chaque navigateur ouvert sur FIWAKTI : Ctrl+F5 (rechargement complet)." -ForegroundColor Cyan
